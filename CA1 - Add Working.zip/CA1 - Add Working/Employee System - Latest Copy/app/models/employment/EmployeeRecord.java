// Idea here is that we can have a record kept for each employee (a one to one mapping with that employee) - but that can also be updated / accessed by a manager.


//Based on the OneToOne mapping like Address - just added functionality with manager also having some access too.


// Sent Patricia an email asking about this - might be a better idea to keep these details in the Employee class itself if it's too complicated....