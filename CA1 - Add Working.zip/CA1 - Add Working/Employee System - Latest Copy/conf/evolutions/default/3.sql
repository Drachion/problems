# --- !Ups

delete from user;

insert into user (id,type,email,role,name,password) values (1,'a','jamesadmin@employees.com','admin','James Admin', 'password');

insert into user (id,type,email,role,name,password) values (2,'m','stephenmanager@employees.com','manager','Stephen Manager', 'password');

insert into user (id,type,email,role,name,password) values (3,'e','tomcruise@employees.com','employee','Tom Employee', 'password');

