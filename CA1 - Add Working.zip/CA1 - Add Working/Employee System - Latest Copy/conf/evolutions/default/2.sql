# --- Sample dataset
 
# --- !Ups
 
delete from item_on_sale;
delete from project;
 
insert into project (id,name) values ( 1,'Dundrum Shopping Centre' );
insert into project (id,name) values ( 2,'Becaon South Quarter' );
insert into project (id,name) values ( 3,'Adamstown LUAS' );
insert into project (id,name) values ( 4,'Dun Laoghaire Marina' );
insert into project (id,name) values ( 5,'Tallaght Stadium' );
insert into project (id,name) values ( 6,'Knocklyon Offices' );
